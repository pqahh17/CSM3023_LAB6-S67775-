package Lab6.com;

public class Student {
    private String studno;
    private String studname;
    private String stuprogram;

    public String getStudno() {
        return studno;
    }

    public void setStudno(String studno) {  // Corrected method name
        this.studno = studno;
    }

    public String getStudname() {
        return studname;
    }

    public void setStudname(String studname) {
        this.studname = studname;
    }

    public String getStuprogram() {
        return stuprogram;
    }

    public void setStuprogram(String stuprogram) {
        this.stuprogram = stuprogram;
    }
}
